package com.yy.yoyo.mapper;


import com.yy.yoyo.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserMapper {

    int addUser(User user);

    User findUserByUsername(String username);

    int updateUserPwdById(@Param("id") int id,@Param("password") String password);

    int updateUserById(User user);

    List<User> getUserList(@Param("startIndex") int page, @Param("pageSize") int size);

    User findUserById(@Param("id") int id);
}
