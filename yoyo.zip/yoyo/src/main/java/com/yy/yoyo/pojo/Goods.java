package com.yy.yoyo.pojo;


import lombok.Data;

@Data
public class Goods {
    int id;
    String name;
    double price;
    String intro;
    String cover;
    String image1;
    String image2;
    int stock;
    int typeId;
    int status;

    Type type;

    boolean topToday = false;
    boolean topHot = false;
    boolean topNew = false;

}