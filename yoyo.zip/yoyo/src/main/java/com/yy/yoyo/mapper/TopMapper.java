package com.yy.yoyo.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface TopMapper {
    //2.热销，3.新品，获取推荐的商品总数
    int getGoodsCountByType(int type);

    int getGoodsCountByGoodsIdAndType(@Param("type") int type, @Param("goodsId") int goodsId);

    void deleteTopByGoodsId(Integer goodsId);

    int deleteTopByGDAndType(@Param("goodsId") int goodsId, @Param("type") int type);

    int insertGoodsToTop(@Param("type") int type, @Param("goodsId") int goodsId);

}
