package com.yy.yoyo.service;

import com.yy.yoyo.pojo.User;

import java.util.List;
import java.util.Map;

public interface UserService {
    Map<String, Object> handleReg(User user);
    Map<String, Object> handleLog(String username , String password);
    Map<String, Object> handleFg(String username , String phone);
    Map<String, Object> handlemy(User user, int type ,   String currentPwd , String pwdNew);
    List<User> handleUserList(int page, int size);
}
