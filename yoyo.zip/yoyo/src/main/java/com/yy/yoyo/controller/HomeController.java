package com.yy.yoyo.controller;


import com.yy.yoyo.pojo.Goods;
import com.yy.yoyo.pojo.Type;
import com.yy.yoyo.service.HomeService;
import com.yy.yoyo.service.impl.HomeServiceImpl;
import com.yy.yoyo.utils.PageUtil;
import org.apache.catalina.filters.ExpiresFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.HttpSessionRequiredException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

//@RestController

@Controller

public class HomeController {

    @Autowired
    HomeServiceImpl homeService;

    @GetMapping({"/","/index"})
    public String toIndex() {
        return "/index.jsp";
    }

    @GetMapping("/index/index")
    public String index(HttpServletRequest request){
        request.setAttribute("flag","1");

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);

        List<Goods> goods1 = homeService.getGoodsListByType(1);
        request.setAttribute("top1List",goods1);

        List<Goods> goods2 = homeService.getGoodsListByType(2);
        request.setAttribute("top2List",goods2);

        List<Goods> goods3 = homeService.getGoodsListByType(3);
        request.setAttribute("top3List",goods3);

        return "/index/index.jsp";
    }

    @RequestMapping("/index/top")
    public String top(HttpServletRequest request, int typeid , int page , int size){

        request.setAttribute("flag",typeid + 5 );

        request.setAttribute("typeid",typeid);

        List<Type> types = homeService.getAllTypes();

        request.setAttribute("typeList",types);

        List<Goods> goods = homeService.getGoodsPageByTopType(typeid,page,size);
        request.setAttribute("goodList",goods);

        int total = homeService.getGoodsTotalByTopType(typeid);

        String pageStr = PageUtil.getPageTool(request,total,page,size);
        request.setAttribute("pageTool",pageStr);


        return "/index/goods.jsp";
    }




}
