package com.yy.yoyo.mapper;

import com.yy.yoyo.pojo.Admin;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
@Mapper
public interface AdminMapper {

    Admin getAdminInfoByUsername(String username);

    // 其他可能的方法...

}