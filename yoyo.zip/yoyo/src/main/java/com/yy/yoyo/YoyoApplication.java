package com.yy.yoyo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YoyoApplication {

    public static void main(String[] args) {
        SpringApplication.run(YoyoApplication.class, args);
    }

}
