package com.yy.yoyo.pojo;

import lombok.Data;

@Data
public class Item {
    int id;
    double price;
    int amount;
    int goodId;
    int orderId;

    Goods goods;
}