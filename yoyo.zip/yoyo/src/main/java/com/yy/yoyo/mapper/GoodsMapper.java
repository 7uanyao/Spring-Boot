package com.yy.yoyo.mapper;

import com.yy.yoyo.pojo.Goods;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
@Mapper
public interface GoodsMapper {

    List<Goods> getGoodsListByTopType(int type);

    List<Goods> getGoodsListPageByTopType(@Param("typeId") int typeId,@Param("startIndex") int startIndex,@Param("pageSize") int pageSize);

    List<Goods> getGoodsListPageByTypeId(@Param("typeId") int typeId,@Param("startIndex") int startIndex,@Param("pageSize") int pageSize);

    List<Goods> getGoodsAdListPageByType(@Param("type") int type,@Param("startIndex") int startIndex,@Param("pageSize") int pageSize);

    int getGoodsTotalByTypeId(int typeId);

    List<Goods> getGoodsListByKw(@Param("keyword") String keyword ,@Param("startIndex") int startIndex,@Param("pageSize") int pageSize);

    int getGoodsTotalByKw( String keyword);
    
    Goods getGoodsInfoById(int id);

    int insertGoods(Goods goods);

    int updateGoods(Goods goods);

    boolean deleteGoods(Integer id);




}
