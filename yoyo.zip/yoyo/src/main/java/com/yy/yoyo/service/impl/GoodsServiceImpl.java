package com.yy.yoyo.service.impl;

import com.yy.yoyo.mapper.GoodsMapper;
import com.yy.yoyo.mapper.TopMapper;
import com.yy.yoyo.mapper.TypeMapper;
import com.yy.yoyo.pojo.Goods;
import com.yy.yoyo.pojo.Type;
import com.yy.yoyo.service.GoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GoodsServiceImpl implements GoodsService {
    @Autowired
    GoodsMapper goodMapper;
    @Autowired
    TypeMapper typeMapper;
    @Autowired
    TopMapper topMapper;
    //实现获取指定商品分类信息（分页）
    @Override
    public List<Goods> getGoodsPageByTypeId(int typeId, int page, int size) {
        return goodMapper.getGoodsListPageByTypeId(typeId,(page-1)*size,size);
    }

    //获取指定分类商品分类信息
    @Override
    public Type getTypeInfoById(int typeId) {
        return typeMapper.getGoodsTypeById(typeId);
    }

    @Override
    public int getGoodsTotalByTypeId(int typeId) {
        return goodMapper.getGoodsTotalByTypeId(typeId);
    }

    @Override
    public List<Goods> getGoodsListPageByKw(String kw, int page, int size) {
        return goodMapper.getGoodsListByKw("%" + kw + "%",(page-1)*size,size);
    }

    @Override
    public int getGoodsTotalPageByKw(String kw) {
        return goodMapper.getGoodsTotalByKw("%" + kw + "%");
    }

    @Override
    public Goods getGoodsInfoById(int id) {

        Goods goodsInfo = goodMapper.getGoodsInfoById(id);

        int typeId = goodsInfo.getTypeId();
        //System.out.println(typeId);
        Type typeInfo = typeMapper.getGoodsTypeById(typeId);

        goodsInfo.setType(typeInfo);


        return goodsInfo;
    }

    @Override
    public List<Goods> getGoodsAdPageByTypeId(int status, int page, int size) {

        List<Goods> goodsList = goodMapper.getGoodsAdListPageByType(status, (page - 1) * size, size);
        for (Goods goods : goodsList) {
            // 获取当前商品的分类信息
            int typeId = goods.getTypeId(); // 获取当前分类的id
            Type typeInfo = typeMapper.getGoodsTypeById(typeId); // 根据指定的分类id获取分类信息
            goods.setType(typeInfo); // 把当前分类信息赋值给当前商品的type属性

            // 判断当前商品是否加入今日推荐
            boolean isTopToday = topMapper.getGoodsCountByGoodsIdAndType(1, goods.getId()) > 0 ? true : false;
            goods.setTopToday(isTopToday); // 把判断结果赋值给当前商品内部

            // 判断当前商品是否加入热销
            boolean isTopHot = topMapper.getGoodsCountByGoodsIdAndType(2, goods.getId()) > 0 ? true : false;
            goods.setTopHot(isTopHot); // 把判断结果赋值给当前商品内部

            // 判断当前商品是否加入新品推荐
            boolean isTopNew = topMapper.getGoodsCountByGoodsIdAndType(3, goods.getId()) > 0 ? true : false;
            goods.setTopNew(isTopNew); // 把判断结果赋值给当前商品内部
        }


        return goodsList;
    }
}