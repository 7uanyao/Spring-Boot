package com.yy.yoyo.mapper;

import com.yy.yoyo.pojo.Order;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface OrderMapper {

    int insertDataToOrder(Order order);

    int updateOrder(Order order);

    List<Order> getOrderByUserId(int userId);

    int updateOrderById(@Param("status") int status, @Param("id") int id);

    List<Order> getOrderListPageByStatus(@Param("status") int status,@Param("startIndex") int page,@Param("pageSize") int size);

    List<Order> getAllOrder(@Param("startIndex") int page,@Param("pageSize") int size);

}
