package com.yy.yoyo.controller;

import com.yy.yoyo.pojo.Order;
import com.yy.yoyo.pojo.Type;
import com.yy.yoyo.pojo.User;
import com.yy.yoyo.service.UserService;
import com.yy.yoyo.service.impl.HomeServiceImpl;
import com.yy.yoyo.service.impl.OrderServiceImpl;
import com.yy.yoyo.service.impl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;


@Controller
public class UserController {

    @Autowired
    HomeServiceImpl homeService;
    @Autowired
    UserServiceImpl userService;
    @Autowired
    OrderServiceImpl orderService;


    @GetMapping("/index/register")
    public String reg(HttpServletRequest request){

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);

        request.setAttribute("flag",5);
        return "/index/register.jsp";
    }

    @PostMapping("/index/register")
    public String doreg(HttpServletRequest request, User user){

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);

        request.setAttribute("flag",5);

        Map<String, Object> res = userService.handleReg(user);

        System.out.println(res);

        if(res.get("code").toString().equals("200")){

            return "redirect:/index/login";

        }else {

            request.setAttribute("msg",res.get("msg"));
            return "/index/register.jsp";

        }

    }


    @GetMapping("/index/login")
    public String log(HttpServletRequest request){

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);

        request.setAttribute("flag",6);
        return "/index/login.jsp";
    }

    @PostMapping("/index/login")
    public String dolog(HttpServletRequest request, String username ,String password){

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);

        request.setAttribute("flag",6);

        Map<String, Object> log = userService.handleLog(username,password);

        System.out.println(log);

        if(log.get("code").toString().equals("200")){

            HttpSession session = request.getSession();
            session.setAttribute("user",log.get("userInfo"));

            return "redirect:/index/index";

        }else {

            request.setAttribute("msg",log.get("msg"));
            return "/index/login.jsp";

        }

    }



    @GetMapping("/index/logout")
    public String logout(HttpServletRequest request, String username ,String password){

        HttpSession session = request.getSession();
        User userInfo = (User) session.getAttribute("user");
        if (userInfo == null) {

            return "redirect:/index/login";

        }
        session.removeAttribute("user");

        return "redirect:/index/index";

    }



    @GetMapping("/index/forget")
    public String forget(HttpServletRequest request){

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);

        request.setAttribute("flag",6);
        return "/index/forget.jsp";
    }

    @PostMapping("/index/forget")
    public String forget(HttpServletRequest request, String username ,String phone){

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);

        request.setAttribute("flag",6);

        Map<String, Object> fg = userService.handleFg(username,phone);

        System.out.println(fg);

        if(fg.get("code").toString().equals("200")){

            return "redirect:/index/login";

        }else {

            request.setAttribute("msg",fg.get("msg"));
            return "/index/login.jsp";

        }


    }

    @GetMapping ("/index/my")
    public String my(HttpServletRequest request){

        HttpSession session = request.getSession();
        User userInfo = (User) session.getAttribute("user");

        if (userInfo == null) {
            return "redirect:/index/login";
        }

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);

        request.setAttribute("flag",4);


        return "/index/my.jsp";

    }

    @PostMapping("/index/my")
    public String my(HttpServletRequest request, User user ,int type , String passwordNew){

        System.out.println(user);
        System.out.println(type);
        System.out.println(passwordNew);

        HttpSession session = request.getSession();
        User userInfo = (User) session.getAttribute("user");

        if (userInfo == null) {
            return "redirect:/index/login";
        }

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);

        request.setAttribute("flag",4);

        Map<String, Object> my = userService.handlemy(user,type,userInfo.getPassword(),passwordNew);

        System.out.println(my);

        if(!my.get("code").toString().equals("200")){

            request.setAttribute("msg",my.get("msg"));

        }else {
            request.setAttribute("msg2",my.get("msg2"));
        }
        return "/index/my.jsp";

    }


    @GetMapping("/index/order")
    public String ord(HttpServletRequest request){

        HttpSession session = request.getSession();
        User userInfo = (User) session.getAttribute("user");

        if (userInfo == null) {
            return "redirect:/index/login";
        }

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);

        request.setAttribute("flag",3);

        List<Order> orders = orderService.selectOrderByUserId(userInfo.getId());

        request.setAttribute("orderList" ,orders);



        return "/index/order.jsp";

    }



}
