package com.yy.yoyo.pojo;

import lombok.Data;

@Data
public class Admin {

    int id;
    String username;
    String password;
}