package com.yy.yoyo.mapper;

import com.yy.yoyo.pojo.Item;
import com.yy.yoyo.pojo.Order;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ItemMapper {

    int insertDataToItem(Item item);

    List<Item> getItemByOrderId(int orderId);
}
