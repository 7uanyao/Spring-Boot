package com.yy.yoyo.mapper;

import com.yy.yoyo.pojo.Type;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface TypeMapper {

    List<Type> getAllTypes();

    Type getGoodsTypeById(int id);


}
