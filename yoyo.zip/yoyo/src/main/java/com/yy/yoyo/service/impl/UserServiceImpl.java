package com.yy.yoyo.service.impl;

import com.yy.yoyo.mapper.UserMapper;
import com.yy.yoyo.pojo.User;
import com.yy.yoyo.service.UserService;
import com.yy.yoyo.utils.SafeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserMapper userMapper;

    @Override
    public Map<String, Object> handleReg(User user) {

        Map<String, Object> result = new HashMap<>();

        if (user.getUsername() == null || "".equals(user.getUsername())){

            result.put("code",5001);
            result.put("msg","用户名不能为空！");
            return result;

        }

        if (user.getPassword() == null || "".equals(user.getPassword())){

            result.put("code",5002);
            result.put("msg","密码不能为空！");
            return result;

        }

        if (user.getPhone() == null || "".equals(user.getPhone())){

            result.put("code",5003);
            result.put("msg","手机号不能为空！");
            return result;

        }

        User userInfo = userMapper.findUserByUsername(user.getUsername());
        if (userInfo == null) {

            String pwd = user.getPassword();
            pwd = SafeUtil.encode(pwd);
            user.setPassword(pwd);

            int res = userMapper.addUser(user);
            System.out.println(res);
            result.put("code",200);
            result.put("msg","注册成功！");

        }else {

            result.put("code",5004);
            result.put("msg","注册失败，用户已存在");

        }
        return result;
    }

    @Override
    public Map<String, Object> handleLog(String username , String password) {

        Map<String, Object> result = new HashMap<>();

        if (username == null || "".equals(username)){

            result.put("code",5001);
            result.put("msg","用户名不能为空！");
            return result;

        }

        if (password == null || "".equals(password)){

            result.put("code",5002);
            result.put("msg","密码不能为空！");
            return result;

        }

        User userInfo = userMapper.findUserByUsername(username);
        if (userInfo == null) {
            result.put("code", 5003);
            result.put("msg", "用户不存在");
        } else {
            // 密码验证
            password = SafeUtil.encode(password);
            if (password.equals(userInfo.getPassword())) {
                result.put("code", 200);
                result.put("msg", "登录成功！");
                result.put("userInfo",userInfo);
            } else {
                result.put("code", 5009);
                result.put("msg", "密码错误");
            }
        }
        return result;
    }

    @Override
    public Map<String, Object> handleFg(String username, String phone) {

        Map<String, Object> result = new HashMap<>();

        if (username == null || "".equals(username)){

            result.put("code",5001);
            result.put("msg","用户名不能为空！");
            return result;

        }

        if (phone == null || "".equals(phone)){

            result.put("code",5003);
            result.put("msg","手机号不能为空！");
            return result;

        }

        User userInfo = userMapper.findUserByUsername(username);
        if (userInfo == null) {
            result.put("code", 5003);
            result.put("msg", "用户不存在");
        } else {
            if (phone.equals(userInfo.getPhone())) {
                String pwd=SafeUtil.encode("123");
                userMapper.updateUserPwdById(userInfo.getId(),pwd);
                result.put("code", 200);
                result.put("msg", "重置成功！");
                result.put("userInfo",userInfo);
            } else {
                result.put("code", 5010);
                result.put("msg", "手机号错误");
            }
        }
        return result;


    }

    @Override
    public Map<String, Object> handlemy(User user, int type,  String currentPwd ,String pwdNew ) {

        Map<String,Object> result = new HashMap<>();

        if (type == 1) {

            if (user.getName().equals("") || user.getName() == null) {

                result.put("code",5012);
                result.put("msg","收货人不能为空！");
                return result;

            }
            if (user.getPhone().equals("") || user.getPhone() == null) {

                result.put("code",5013);
                result.put("msg","手机号不能为空！");
                return result;

            }
            if (user.getAddress().equals("") || user.getAddress() == null) {

                result.put("code",5014);
                result.put("msg","地址不能为空！");
                return result;

            }
            userMapper.updateUserById(user);
            result.put("code",200);
            result.put("msg2","修改成功！");
            return result;

        }else {
            // 修改密码
            // 1、校验数据完整
            if (user.getPassword().equals("") || user.getPassword() == null) {
                result.put("code", 5015);
                result.put("msg", "原密码不能为空!");
                return result;
            }

            if (pwdNew.equals("") || pwdNew == null) {
                // 校验新密码是否为空
                // 处理逻辑
                result.put("code", 5015);
                result.put("msg", "新密码不能为空!");
                return result;
            }
            // 校验原始密码是否一致
            String pwd = SafeUtil.encode(user.getPassword());
            if (currentPwd.equals(pwd)) {
                // 一致
                System.out.println(pwd);
                System.out.println(currentPwd);
                pwdNew = SafeUtil.encode(pwdNew);
                userMapper.updateUserPwdById(user.getId(),pwdNew);
                result.put("code",200);
                result.put("msg2", "修改成功");
                return result;
            } else {
                // 不一致
                System.out.println(pwd);
                System.out.println(currentPwd);
                result.put("code", 5016);
                result.put("msg", "修改失败，原密码错误!");
                return result;
            }
        }

    }

    @Override
    public List<User> handleUserList(int page, int size) {
        return userMapper.getUserList((page-1)*size,size);
    }
}
