package com.yy.yoyo.service.impl;

import com.yy.yoyo.mapper.AdminMapper;
import com.yy.yoyo.mapper.GoodsMapper;
import com.yy.yoyo.mapper.TopMapper;
import com.yy.yoyo.mapper.TypeMapper;
import com.yy.yoyo.pojo.Admin;
import com.yy.yoyo.pojo.Goods;
import com.yy.yoyo.service.AdminService;
import com.yy.yoyo.utils.SafeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

// AdminServiceImpl.java
@Service
public class AdminServiceImpl implements AdminService {


    @Autowired
    AdminMapper adminMapper;
    @Autowired
    GoodsMapper goodsMapper;
    @Autowired
    TopMapper topMapper;

    @Override
    public Map<String, Object> adminLogin(String username, String password) {
        Map<String, Object> result = new HashMap<>();

        // 检查用户名是否为空
        if (username == null || "".equals(username.trim())) {
            result.put("code", 5001);
            result.put("msg", "用户名不能为空!");
            return result;
        }

        // 检查密码是否为空
        if (password == null || "".equals(password.trim())) {
            result.put("code", 5002);
            result.put("msg", "密码不能为空!");
            return result;
        }

        // 根据用户名从数据库获取用户信息
        Admin adminInfo = adminMapper.getAdminInfoByUsername(username);

        // 如果用户不存在
        if (adminInfo == null) {
            result.put("code", 5003);
            result.put("msg", "登录用户不存在!");
        } else {
            // 存在用户，对用户输入的密码进行加密
            String encryptedPassword = SafeUtil.encode(password);

            // 与数据库中的加密密码进行比较
            if (encryptedPassword.equals(adminInfo.getPassword())) {
                // 密码验证通过
                result.put("code", 200);
                result.put("admin", adminInfo);
                System.out.println(adminInfo);
                result.put("msg", "登录成功!");
            } else {
                // 密码验证失败
                result.put("code", 5004);
                result.put("msg", "密码错误!");
            }
        }

        return result;
    }

    @Override
    public Map<String, Object> handleGoodsAdd(HttpServletRequest request, MultipartFile cover, MultipartFile image1, MultipartFile image2) {
        Map<String, Object> result = new HashMap<>();

// 1. 校验数据是否完整
        String name = request.getParameter("name"); // 商品名字
        if (name == null || "".equals(name)) {
            result.put("code", 5004);
            result.put("msg", "商品标题不能为空!");
            return result;
        }

// 2. 校验价格是否有效
        String priceStr = request.getParameter("price");
        if (priceStr == null || "".equals(priceStr)) {
            result.put("code", 5005);
            result.put("msg", "商品价格不能为空!");
            return result;
        }

// 3. 校验介绍是否有效
        String intro = request.getParameter("intro");
        if (intro == null || "".equals(intro)) {
            result.put("code", 5006);
            result.put("msg", "商品介绍不能为空!");
            return result;
        }

// 4. 校验库存是否有效
        String stockStr = request.getParameter("stock");
        if (stockStr == null || "".equals(stockStr)) {
            result.put("code", 5007);
            result.put("msg", "商品库存不能为空!");
            return result;
        }

// 5. 校验商品分类是否有效
        String typeId = request.getParameter("typeId"); // 商品分类
        if (typeId == null || "".equals(typeId)) {
            result.put("code", 5008);
            result.put("msg", "商品分类不能为空!");
            return result;
        }


// 6. 校验商品图片是否为空

        if (cover == null || image1 == null || image2 == null) {
            result.put("code", 5009);
            result.put("msg", "商品图片不能为空!");
            return result;
        }
// 如果通过所有校验，可以进行后续的逻辑，例如创建 Goods 对象，保存到数据库等

// 返回成功的结果
        String basePath = request.getServletContext().getRealPath("/picture");
        System.out.println(basePath);

        String coverPath = handleUploadFile(cover, basePath);
        if (coverPath == null) {
            result.put("code", 5010);
            result.put("msg", "商品封面图片不能为空!");
            return result;
        }
        System.out.println(coverPath);

        // 处理 image1 图片
        String image1Path = handleUploadFile(image1, basePath);
        if (image1Path == null) {
            result.put("code", 5011);
            result.put("msg", "商品图片1不能为空!");
            return result;
        }

        // 处理 image2 图片
        String image2Path = handleUploadFile(image2, basePath);
        if (image2Path == null) {
            result.put("code", 5012);
            result.put("msg", "商品图片2不能为空!");
            return result;
        }

        Goods goods = new Goods();
        goods.setName(name);
        goods.setPrice(Double.parseDouble(priceStr));
        goods.setIntro(intro);
        goods.setStock(Integer.parseInt(stockStr));
        goods.setCover(coverPath);
        goods.setImage1(image1Path);
        goods.setImage2(image2Path);
        System.out.println(goods);

        if (typeId != null && !typeId.isEmpty()) {
            try {
                int typeIdInt = Integer.parseInt(typeId);
                goods.setTypeId(typeIdInt);
            } catch (NumberFormatException e) {
                // 处理转换异常
                e.printStackTrace(); // 可以打印异常信息或进行其他处理
            }
        }

        int addaffect = goodsMapper.insertGoods(goods);

        if (addaffect > 0) {
            // 插入成功
            result.put("code", 200);
            result.put("msg", "商品信息插入成功!");
        } else {
            // 插入失败
            result.put("code", 5013);
            result.put("msg", "商品信息插入失败!");
        }

        return result;
    }

    @Override
    public Map<String, Object> handleGoodsEdit(HttpServletRequest request, MultipartFile cover, MultipartFile image1, MultipartFile image2) {
        Map<String, Object> result = new HashMap<>();

        // 获取要修改的商品ID
        String goodsIdStr = request.getParameter("id");
        System.out.println(goodsIdStr);
        // 1. 校验ID是否为空
        if (goodsIdStr == null || goodsIdStr.isEmpty()) {
            // 缺少商品ID，处理错误逻辑
            result.put("code", 5001);
            result.put("msg", "商品ID不能为空");
            return result;
        }

        String name = request.getParameter("name"); // 商品名字
        if (name == null || "".equals(name)) {
            result.put("code", 5004);
            result.put("msg", "商品标题不能为空!");
            return result;
        }

        // 2. 校验价格是否为空
        String priceStr = request.getParameter("price");
        if (priceStr == null || "".equals(priceStr)) {
            result.put("code", 5005);
            result.put("msg", "商品价格不能为空!");
            return result;
        }

        // 3. 校验介绍是否为空
        String intro = request.getParameter("intro");
        if (intro == null || "".equals(intro)) {
            result.put("code", 5006);
            result.put("msg", "商品介绍不能为空!");
            return result;
        }

        // 4. 校验库存是否为空
        String stockStr = request.getParameter("stock");
        if (stockStr == null || "".equals(stockStr)) {
            result.put("code", 5007);
            result.put("msg", "商品库存不能为空!");
            return result;
        }

        // 5. 校验商品分类是否为空
        String typeId = request.getParameter("typeId"); // 商品分类
        System.out.println(typeId);
        System.out.println("商品类目");
        if (typeId == null || "".equals(typeId)) {
            result.put("code", 5008);
            result.put("msg", "商品分类不能为空!");
            return result;
        }


        // 6. 校验商品图片是否为空

        if (cover == null || image1 == null || image2 == null) {
            result.put("code", 5009);
            result.put("msg", "商品图片不能为空!");
            return result;
        }
        // 如果通过所有校验，可以进行后续的逻辑，例如创建 Goods 对象，保存到数据库等

        // 返回成功的结果
        String basePath = request.getServletContext().getRealPath("/picture");
        System.out.println(basePath);

        String coverPath = handleUploadFile(cover, basePath);
        System.out.println(cover);
        if (coverPath == null && !cover.getOriginalFilename().equals("")) {
            result.put("code", 5010);
            result.put("msg", "商品封面图片格式错误!");
            return result;
        }
        System.out.println(coverPath);

        // 处理 image1 图片
        String image1Path = handleUploadFile(image1, basePath);
        if (image1Path == null && !image1.getOriginalFilename().equals("")) {
            result.put("code", 5011);
            result.put("msg", "商品图片1格式错误!");
            return result;
        }

        // 处理 image2 图片
        String image2Path = handleUploadFile(image2, basePath);
        if (image2Path == null && !image2.getOriginalFilename().equals("")) {
            result.put("code", 5012);
            result.put("msg", "商品图片2格式错误!");
            return result;
        }



        try {
            int goodsId = Integer.parseInt(goodsIdStr);
            Goods goods = new Goods();
            goods.setId(goodsId);
            goods.setName(name);
            if (typeId != null && !typeId.isEmpty()) {
                try {
                    int typeIdInt = Integer.parseInt(typeId);
                    goods.setTypeId(typeIdInt);
                } catch (NumberFormatException e) {
                    // 处理转换异常
                    e.printStackTrace(); // 可以打印异常信息或进行其他处理
                }
            }
            try {
                goods.setPrice(Double.parseDouble(priceStr));
            } catch (NumberFormatException e) {
                // 处理异常的代码
                // 例如，可以记录日志、返回用户错误信息，或采取其他适当的操作
                e.printStackTrace(); // 可以替换为其他处理方式
            }
            goods.setIntro(intro);
            goods.setStock(Integer.parseInt(stockStr));
            goods.setCover(coverPath);
            goods.setImage1(image1Path);
            goods.setImage2(image2Path);
            System.out.println(goods);


            // 执行更新操作
            int updateResult = goodsMapper.updateGoods(goods);

            if (updateResult > 0) {
                // 更新成功
                result.put("code", 200);
                result.put("msg2", "edit-success");
            } else {
                // 更新失败
                result.put("code", 5002);
                result.put("msg", "商品信息更新失败");
            }

        } catch (NumberFormatException e) {
            // 处理商品ID转换异常
            e.printStackTrace();
            result.put("code", 5003);
            result.put("msg", "商品ID格式错误");
        }

        return result;
    }


    private String handleUploadFile(MultipartFile file, String basePath) {
        // 保存上传图片的路径
        String newsFilePath = null;

        // 获取上传图片的真实名字
        String fileName = file.getOriginalFilename();
        System.out.println(fileName);

        // 控制商品文件的类型
        if (fileName.endsWith(".jpg") || fileName.endsWith(".png")) {
            // 获取文件名中最后一个点出现的位置 (下标)
            int dotIndex = fileName.lastIndexOf(".");

            // 获取文件的扩展名
            String extName = fileName.substring(dotIndex);
            String str2 = UUID.randomUUID().toString().replace("-", "");
            String newsFileName = str2 + extName;
            // 基于新的文件路径创建文件对象
            File file1 = new File(basePath + File.separator + newsFileName);

            // 判断文件是否存在
            if (!file1.exists()) {
                // 创建不存在的文件路径
                file1.mkdirs();
            }
            // 保存上传图片
            try {
                file.transferTo(file1);
                // 获取保存后的文件路径
                newsFilePath = "picture/" + newsFileName;
                System.out.println("文件保存路径：" + newsFilePath);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        return newsFilePath;
    }

    @Override
    public boolean deleteGoods(int id) {
        boolean del = goodsMapper.deleteGoods(id);
        topMapper.deleteTopByGoodsId(id);

        return del;
    }

    @Override
    public boolean deleteOrJoinGoods(String operate, int goodsId, int type) {
        int res = 0;
        if ("delete".equals(operate)) {
            // 移除推荐
            res = topMapper.deleteTopByGDAndType(goodsId, type);
        } else {
            // 加入推荐
            res = topMapper.insertGoodsToTop(type, goodsId);
        }
        return res > 0;
    }
}
