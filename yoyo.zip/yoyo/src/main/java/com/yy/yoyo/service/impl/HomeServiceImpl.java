package com.yy.yoyo.service.impl;

import com.yy.yoyo.mapper.GoodsMapper;
import com.yy.yoyo.mapper.TopMapper;
import com.yy.yoyo.mapper.TypeMapper;
import com.yy.yoyo.pojo.Goods;
import com.yy.yoyo.pojo.Type;
import com.yy.yoyo.service.HomeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HomeServiceImpl implements HomeService {
    @Autowired
    TypeMapper typeMapper;
    @Autowired
    GoodsMapper goodsMapper;
    @Autowired
    TopMapper topMapper;

    @Override
    public List<Type> getAllTypes() {
        List<Type> types = typeMapper.getAllTypes();
        return types;
    }

    @Override
    public List<Goods> getGoodsListByType(int type) {
        List<Goods> goods = goodsMapper.getGoodsListByTopType(type);
        for (Goods item : goods){
            int typeId = item.getTypeId();
            Type type1 = typeMapper.getGoodsTypeById(typeId);
            item.setType(type1);
        }
        return goods;
    }

    @Override
    public List<Goods> getGoodsPageByTopType(int typeId, int page, int size) {
        List<Goods> goods = goodsMapper.getGoodsListPageByTopType(typeId, (page-1)*size, size);
        return goods;
    }

    @Override
    public int getGoodsTotalByTopType(int typeId) {
        return topMapper.getGoodsCountByType(typeId);
    }
}
