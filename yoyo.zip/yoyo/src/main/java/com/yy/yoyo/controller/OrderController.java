package com.yy.yoyo.controller;

import com.yy.yoyo.pojo.*;
import com.yy.yoyo.service.impl.HomeServiceImpl;
import com.yy.yoyo.service.impl.OrderServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@Controller
public class OrderController {

    @Autowired
    HomeServiceImpl homeService;
    @Autowired
    OrderServiceImpl orderService;

    @GetMapping("/index/cart")
    public String cart(HttpServletRequest request){

        HttpSession session = request.getSession();
        User userInfo = (User) session.getAttribute("user");

        if (userInfo == null) {
            return "redirect:/index/login";
        }

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);

        return "/index/cart.jsp";

    }


    @PostMapping("/index/addToCart")
    public void addToCart(HttpServletRequest request, HttpServletResponse response,  int goodid) throws IOException {
        // 1、登录检查
        // 获取session对象
        HttpSession session = request.getSession();

        // 根据user键从session中获取当前登录的用户信息
        User userInfo = (User) session.getAttribute("user");

        // 判断是否登录
        if (userInfo == null) {
            // getWriter获取写对象，write向响应对象中写入要返回给浏览器的内容
            response.getWriter().write("login");
            return;
        }

        // 2、获取购物车数据(虚拟的订单信息)
        Order orders = (Order) session.getAttribute("order");

        Map<String, Object> res = orderService.addGoodsToCart(goodid, orders, userInfo);
        System.out.println(res);

        if ("200".equals(res.get("code").toString())) {
            // 获取虚拟订单
            Order order = (Order) res.get("order");

            // 保存购物车数据到session
            session.setAttribute("order", order);

            // 商品添加到购物车成功
            response.getWriter().write("ok");
        } else {
            response.getWriter().write(res.get("msg").toString());
        }
    }

    @PostMapping("/index/lessen")
    public void lesToCart(HttpServletRequest request, HttpServletResponse response,  int goodid) throws IOException {
        // 1、登录检查
        // 获取session对象
        HttpSession session = request.getSession();

        // 根据user键从session中获取当前登录的用户信息
        User userInfo = (User) session.getAttribute("user");

        // 判断是否登录
        if (userInfo == null) {
            // getWriter获取写对象，write向响应对象中写入要返回给浏览器的内容
            response.getWriter().write("login");
            return;
        }

        // 2、获取购物车数据(虚拟的订单信息)
        Order orders = (Order) session.getAttribute("order");

        Map<String, Object> res = orderService.updateCartInfo(goodid, orders);
        System.out.println(res);

        if ("200".equals(res.get("code").toString())) {
            // 获取虚拟订单
            Order order = (Order) res.get("order");

            // 保存购物车数据到session
            session.setAttribute("order", order);

            // 商品更新成功
            response.getWriter().write("ok");
        } else {
            response.getWriter().write(res.get("msg").toString());
        }
    }

    @PostMapping("/index/delete")
    public void delToCart(HttpServletRequest request, HttpServletResponse response,  int goodid) throws IOException {
        // 1、登录检查
        // 获取session对象
        HttpSession session = request.getSession();

        // 根据user键从session中获取当前登录的用户信息
        User userInfo = (User) session.getAttribute("user");

        // 判断是否登录
        if (userInfo == null) {
            // getWriter获取写对象，write向响应对象中写入要返回给浏览器的内容
            response.getWriter().write("login");
            return;
        }

        // 2、获取购物车数据(虚拟的订单信息)
        Order orders = (Order) session.getAttribute("order");

        Map<String, Object> res = orderService.deleteCartInfo(goodid, orders);
        System.out.println(res);

        if ("200".equals(res.get("code").toString())) {
            // 获取虚拟订单
            Order order = (Order) res.get("order");

            // 保存购物车数据到session
            session.setAttribute("order", order);

            // 商品更新成功
            response.getWriter().write("ok");
        } else {
            response.getWriter().write(res.get("msg").toString());
        }
    }


    @GetMapping("/index/placeOrder")
    public String placeOrder(HttpServletRequest request) {
        // 1、登录检查
        // 获取session对象
        HttpSession session = request.getSession();

        // 根据user键从session中获取当前登录的用户信息
        User userInfo = (User) session.getAttribute("user");

        // 判断是否登录
        if (userInfo == null) {
            return "redirect:/index/login";
        }

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);

        // 其他业务逻辑...
        Order orders = (Order) session.getAttribute("order");


        Map<String, Object> res = orderService.createRealOrder(orders);
        System.out.println(res);

        if ("200".equals(res.get("code").toString())) {

            //session.removeAttribute("order");
            return "/index/pay.jsp";
        } else {
            request.setAttribute("msg2",res.get("msg").toString());
            return "/index/cart.jsp";
        }


    }

    @PostMapping("/index/pay")
    public String pay(HttpServletRequest request, Order order){

        HttpSession session = request.getSession();

        // 根据user键从session中获取当前登录的用户信息
        User userInfo = (User) session.getAttribute("user");

        // 判断是否登录
        if (userInfo == null) {
            return "redirect:/index/login";
        }

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);


        Map<String, Object> res = orderService.updateOrder(order);
        System.out.println(res);

        if ("200".equals(res.get("code").toString())) {
            session.removeAttribute("order");
            request.setAttribute("msg","支付成功!");
        } else {
            request.setAttribute("msg2",res.get("msg").toString());
        }
        return "/index/payok.jsp";

    }

    @GetMapping("/index/topay")
    public String topay(HttpServletRequest request,int orderid){

        HttpSession session = request.getSession();

        // 根据user键从session中获取当前登录的用户信息
        User userInfo = (User) session.getAttribute("user");

        // 判断是否登录
        if (userInfo == null) {
            return "redirect:/index/login";
        }

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);


        List<Order> orders = orderService.selectOrderByUserId(userInfo.getId());

        Order targetOrder = null;
        for (Order order : orders) {
            if (order.getId() == orderid) {
                targetOrder = order;
                break;
            }
        }

        System.out.println(targetOrder);

        request.setAttribute("order",targetOrder);
        return "/index/pay.jsp";




    }




}
