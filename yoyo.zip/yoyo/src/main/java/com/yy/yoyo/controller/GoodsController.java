package com.yy.yoyo.controller;

import com.yy.yoyo.pojo.Goods;
import com.yy.yoyo.pojo.Type;
import com.yy.yoyo.service.impl.GoodsServiceImpl;
import com.yy.yoyo.service.impl.HomeServiceImpl;
import com.yy.yoyo.utils.PageUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;


@Controller
public class GoodsController {
    @Autowired
    HomeServiceImpl homeService;
    @Autowired
    GoodsServiceImpl goodsService;


    //商品分类列表页：~/index/goods
    @GetMapping("/index/goods")
    public String goods(HttpServletRequest request,int typeid,int page,int size){
        //1.添加新的属性
        //flag计算index.jsp中的flag变量
        request.setAttribute("flag",2);    //key,value
        //2.商品分类数据
        List<Type> types = homeService.getAllTypes();
        //typeList只能用于jsp页面
        request.setAttribute("typeList",types);

        //3.根据商品分类获取商品列表
        List<Goods> goods = goodsService.getGoodsPageByTypeId(typeid,page,size);
        request.setAttribute("goodList",goods);
        //4.根据点击分类id获取分类详情
        Type type = goodsService.getTypeInfoById(typeid);
        request.setAttribute("type",type);


        int total = goodsService.getGoodsTotalByTypeId(typeid);
        String pageStr = PageUtil.getPageTool(request,total,page,size);
        request.setAttribute("pageTool",pageStr);

        return "/index/goods.jsp";
    }


    //商品搜索页：~/index/search
    @PostMapping("/index/search")
    public String search(HttpServletRequest request,String name,int page,int size){

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);

        List<Goods> goods = goodsService.getGoodsListPageByKw(name,page,size);
        request.setAttribute("goodList",goods);

        request.setAttribute("typeid",4);

        int total = goodsService.getGoodsTotalPageByKw(name);
        String pageStr = PageUtil.getPageTool(request,total,page,size);
        request.setAttribute("pageTool",pageStr);




        return "/index/goods.jsp";
    }

    @GetMapping("/index/detail")
    public String detail(HttpServletRequest request,int goodid){

        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList",types);

        Goods goodsInfo = goodsService.getGoodsInfoById(goodid);
        request.setAttribute("good",goodsInfo);


        return "/index/detail.jsp";
    }

}