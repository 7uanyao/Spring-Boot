package com.yy.yoyo.pojo;


import lombok.Data;

@Data
public class User {

    int id;
    String username;
    String password;
    String name;
    String phone;
    String address;
    int status;


}
