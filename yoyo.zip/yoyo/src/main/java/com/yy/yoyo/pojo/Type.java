package com.yy.yoyo.pojo;

import lombok.Data;

@Data
public class Type {
    int id;
    String name;
    int status;
}