package com.yy.yoyo.service;

import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

public interface AdminService {

    Map<String, Object> adminLogin(String username, String password);

    Map<String, Object> handleGoodsAdd(HttpServletRequest request , MultipartFile cover , MultipartFile image1 , MultipartFile image2);

    Map<String, Object> handleGoodsEdit(HttpServletRequest request , MultipartFile cover , MultipartFile image1 , MultipartFile image2);

    boolean deleteGoods(int id);

    boolean deleteOrJoinGoods(String operate , int goodsId, int type);


}