package com.yy.yoyo.controller;

import com.yy.yoyo.pojo.*;
import com.yy.yoyo.service.UserService;
import com.yy.yoyo.service.impl.AdminServiceImpl;
import com.yy.yoyo.service.impl.GoodsServiceImpl;
import com.yy.yoyo.service.impl.HomeServiceImpl;
import com.yy.yoyo.service.impl.OrderServiceImpl;
import com.yy.yoyo.utils.PageUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.net.MulticastSocket;
import java.util.List;
import java.util.Map;

@Controller
public class AdminController {

    @Autowired
    AdminServiceImpl adminService;
    @Autowired
    GoodsServiceImpl goodsService;
    @Autowired
    HomeServiceImpl homeService;
    @Autowired
    OrderServiceImpl orderService;
    @Autowired
    UserService userService;

    // 1. 跳转界面 http://127.0.0.1:9527/admin
    @GetMapping("/admin")
    public String toAdminPage() {
        return "/admin.jsp";
    }

    // 2. 后端登录界面 http://127.0.0.1:9527/admin/login
    @GetMapping("/admin/login")
    public String login() {
        return "/admin/login.jsp";
    }

    @PostMapping("/admin/login")
    public String login(HttpServletRequest request, String username, String password) {
        // 调用服务进行业务处理
        Map<String, Object> res = adminService.adminLogin(username, password);

        // 根据服务返回的结果进行处理
        if ("200".equals(res.get("code").toString())) {
            HttpSession session = request.getSession();

            // 获取管理员信息并设置到 session 中
            Admin adminInfo = (Admin) res.get("admin");
            session.setAttribute("admin", adminInfo);

            System.out.println(adminInfo);
            // 登录成功，跳转到后台首页
            return "redirect:/admin/index";
        } else {
            // 登录失败，根据需要进行处理（重定向、错误消息等）
            return "redirect:/login";
        }
    }

    @GetMapping("/admin/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession();
        Admin adminInfo = (Admin) session.getAttribute("admin");

        if (adminInfo == null) {
            // 如果用户信息为空，可能已经注销或者未登录，重定向到登录页面
            return "redirect:/admin/login";
        }

        // 移除Session中的用户信息
        session.removeAttribute("admin");

        // 重定向到登录页面
        return "redirect:/admin/login";
    }

    // 3. 后端首页界面 http://127.0.0.1:9527/admin/index
    @GetMapping("/admin/index")
    public String adminIndex(HttpServletRequest request) {
        HttpSession session = request.getSession();
        Admin adminInfo = (Admin) session.getAttribute("admin");

        if (adminInfo == null) {
            // 如果用户信息为空，可能已经注销或者未登录，重定向到登录页面
            return "redirect:/admin/login";
        }
        return "/admin/index.jsp";
    }

    @GetMapping("/admin/goodsList")
    public String goodsList(HttpServletRequest request, @RequestParam int status, @RequestParam int page, @RequestParam int size) {

        HttpSession session = request.getSession();
        Admin adminInfo = (Admin) session.getAttribute("admin");

        if (adminInfo == null) {
            // 如果用户信息为空，可能已经注销或者未登录，重定向到登录页面
            return "redirect:/admin/login";
        }

        // 控制tabs选项卡选中
        request.setAttribute("status", status);

        // 获取对应的数据，status表示全部(0)，1表示今日推荐，2表示热门，3表示新品
        List<Goods> goodsList = goodsService.getGoodsAdPageByTypeId(status, page, size);
        request.setAttribute("goodsList",goodsList);
        System.out.println(goodsList);

        int total = goodsService.getGoodsTotalByTypeId(status);
        String pageStr = PageUtil.getPageTool(request,total,page,size);
        request.setAttribute("pageTool",pageStr);

        String msg = request.getParameter("msg2");
        request.setAttribute("msg2", msg);
        System.out.println(msg);

        return "/admin/goods_list.jsp";
    }

    @GetMapping("/admin/goodsAdd")
    public String goodsAdd(HttpServletRequest request) {

        HttpSession session = request.getSession();
        Admin adminInfo = (Admin) session.getAttribute("admin");

        if (adminInfo == null) {
            // 如果用户信息为空，可能已经注销或者未登录，重定向到登录页面
            return "redirect:/admin/login";
        }

        List<Type> types = homeService.getAllTypes();

        request.setAttribute("typeList",types);



        return "/admin/goods_add.jsp";
    }

    @PostMapping("/admin/goodsAdd")
    public String goodsAdd(HttpServletRequest request , MultipartFile cover , MultipartFile image1 , MultipartFile image2) {

        HttpSession session = request.getSession();
        Admin adminInfo = (Admin) session.getAttribute("admin");

        if (adminInfo == null) {
            // 如果用户信息为空，可能已经注销或者未登录，重定向到登录页面
            return "redirect:/admin/login";
        }

        List<Type> types = homeService.getAllTypes();

        request.setAttribute("typeList",types);

        Map<String, Object> res = adminService.handleGoodsAdd(request,cover,image1,image2);

        if ("200".equals(res.get("code").toString())) {
            request.setAttribute("msg2",res.get("msg").toString());
        } else {
            request.setAttribute("msg",res.get("msg").toString());
        }
        return "/admin/goods_add.jsp";


    }

    @GetMapping("/admin/goodsEdit")
    public String goodsEdit(HttpServletRequest request, @RequestParam int id, @RequestParam int status) {
        // 获取管理员信息
        HttpSession session = request.getSession();
        Admin adminInfo = (Admin) session.getAttribute("admin");

        if (adminInfo == null) {
            // 如果管理员信息为空，可能已经注销或者未登录，重定向到登录页面
            return "redirect:/admin/login";
        }

        // 获取所有商品分类
        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList", types);

        // 获取指定商品信息
        Goods goodsInfo = goodsService.getGoodsInfoById(id);
        request.setAttribute("goods", goodsInfo);
        request.setAttribute("status", status);
        System.out.println("------------正在修改的商品信息-----------");
        System.out.println(goodsInfo);

        // 跳转到商品编辑页面
        return "/admin/goods_edit.jsp";
    }

    @PostMapping("/admin/goodsEdit")
    public String goodsEdit(HttpServletRequest request, @RequestParam("id") String id,
                            MultipartFile cover, MultipartFile image1, MultipartFile image2) {
        // 获取管理员信息
        HttpSession session = request.getSession();
        Admin adminInfo = (Admin) session.getAttribute("admin");

        if (adminInfo == null) {
            // 如果管理员信息为空，可能已经注销或者未登录，重定向到登录页面
            return "redirect:/admin/login";
        }

        // 获取所有商品分类
        List<Type> types = homeService.getAllTypes();
        request.setAttribute("typeList", types);

        // 设置商品ID
        request.setAttribute("id", id);
        String goodsIdStr = (String) request.getAttribute("id");
//        String goodsIdStr2 = request.getParameter("id");
//        System.out.println("---------- id值：------------");
//        System.out.println(goodsIdStr);
//        System.out.println(goodsIdStr2);

        // 处理商品编辑操作
        Map<String, Object> res = adminService.handleGoodsEdit(request, cover, image1, image2);

        // 根据处理结果设置页面提示信息
        if ("200".equals(res.get("code").toString())) {

            // 重定向到商品列表页面
            return "redirect:/admin/goodsList?status=0&page=1&size=16&msg2=" + res.get("msg2").toString();
        } else {
            try {
                int goodsId = Integer.parseInt(goodsIdStr);
                Goods goodsInfo = goodsService.getGoodsInfoById(goodsId);
                request.setAttribute("goods", goodsInfo);
            } catch (NumberFormatException e) {
                // 处理商品ID转换异常
                e.printStackTrace();
            }
            request.setAttribute("msg", res.get("msg").toString());
            return "/admin/goods_edit.jsp";
        }


    }

    @GetMapping("/admin/goodsDelete")
    public String goodsDelete(HttpServletRequest request, @RequestParam("id") int id,int status) {
        // 1.检查是否登录
        HttpSession session = request.getSession();
        Admin adminInfo = (Admin) session.getAttribute("admin");
        if (adminInfo == null) {
            return "redirect:/admin/login";
        }

        // 2.删除逻辑
        adminService.deleteGoods(id);

        return "redirect:/admin/goodsList?status=0&page=1&size=16";
    }

    @PostMapping("/admin/topOperate")
    public void topOperate(HttpServletRequest request,
                           HttpServletResponse response,
                           String operate,
                           int goodsId,
                           int type) throws IOException {
        // 1. 检查是否登录
        HttpSession session = request.getSession();
        Admin adminInfo = (Admin) session.getAttribute("admin");
        if (adminInfo == null) {
            response.getWriter().write("请登录!");
            return;
        }
        // 其他逻辑
        boolean res = adminService.deleteOrJoinGoods(operate, goodsId, type);
        response.getWriter().write(res ? "ok" : "操作失败! ");

    }

    @GetMapping("/admin/adminRe")
    public String adminRe(HttpServletRequest request) {
        Admin admin = (Admin) request.getSession().getAttribute("admin");
        if (admin == null) {
            return "/admin/login.jsp";
        }else {
            request.setAttribute("flag", 5);
            return "/admin/admin_reset.jsp";
        }
    }

    @GetMapping("/admin/typeList")
    public String adminList(HttpServletRequest request) {
        Admin admin = (Admin) request.getSession().getAttribute("admin");
        if (admin == null) {
            return "/admin/login.jsp";
        }else {
            request.setAttribute("flag", 4);
            List<Type> types = homeService.getAllTypes();
            request.setAttribute("typeList", types);
            return "/admin/type_list.jsp";
        }
    }

    @GetMapping("/admin/userList")
    public String userList(HttpServletRequest request, int page, int size) {
        Admin admin = (Admin) request.getSession().getAttribute("admin");
        if (admin == null) {
            return "/admin/login.jsp";
        }else {
            request.setAttribute("flag", 2);
            List<User> users = userService.handleUserList(page, size);
            request.setAttribute("userList", users);
            String pageTool = PageUtil.getPageTool(request, users.size(), page, size);
            request.setAttribute("pageTool", pageTool);
            return "/admin/user_list.jsp";
        }
    }



}
