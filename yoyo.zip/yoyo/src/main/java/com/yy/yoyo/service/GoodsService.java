package com.yy.yoyo.service;

import com.yy.yoyo.pojo.Goods;
import com.yy.yoyo.pojo.Type;

import java.util.List;

public interface GoodsService {
    List<Goods> getGoodsPageByTypeId(int typeId, int page, int size);
    List<Goods> getGoodsAdPageByTypeId(int status, int page, int size);
    Type getTypeInfoById(int typeId);
    int getGoodsTotalByTypeId(int typeId);
    List<Goods> getGoodsListPageByKw(String kw , int page, int size);
    int getGoodsTotalPageByKw(String kw);
    Goods getGoodsInfoById(int id);
}
