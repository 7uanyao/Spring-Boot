package com.yy.yoyo.service;

import com.yy.yoyo.pojo.User;
import com.yy.yoyo.pojo.Order;

import java.util.List;
import java.util.Map;

public interface OrderService {

    Map<String, Object> addGoodsToCart(int goodsId, Order order, User user);

    Map<String, Object> updateCartInfo(int goodsId , Order order);

    Map<String, Object> deleteCartInfo(int goodsId , Order order);

    Map<String, Object> createRealOrder(Order order);


    Map<String, Object> updateOrder(Order order);

    List<Order> selectOrderByUserId(int userId);

    List<Order> handleOrderByStatus(int status, int page, int size);

    int handleOrderOperate(String operate, int id);


}
