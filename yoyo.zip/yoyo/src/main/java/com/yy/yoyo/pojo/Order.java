package com.yy.yoyo.pojo;

import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class Order {
    int id;
    double total;
    int amount;
    int status;
    int paytype;
    String name;
    String phone;
    String address;
    String systime;
    int userId;

    User user;

    List<Item> itemList;



}