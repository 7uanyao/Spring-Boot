package com.yy.yoyo.service.impl;

import com.yy.yoyo.mapper.GoodsMapper;
import com.yy.yoyo.mapper.ItemMapper;
import com.yy.yoyo.mapper.OrderMapper;
import com.yy.yoyo.mapper.UserMapper;
import com.yy.yoyo.pojo.Goods;
import com.yy.yoyo.pojo.Item;
import com.yy.yoyo.pojo.Order;
import com.yy.yoyo.pojo.User;
import com.yy.yoyo.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    GoodsMapper goodsMapper;
    @Autowired
    OrderMapper orderMapper;
    @Autowired
    ItemMapper itemMapper;
    @Autowired
    UserMapper userMapper;



    @Override
    public Map<String, Object> addGoodsToCart(int goodsId, Order order, User user) {
        Map<String, Object> result = new HashMap<>();

        Goods goods = goodsMapper.getGoodsInfoById(goodsId);

        if (goods == null) {
            result.put("code", 5019);
            result.put("msg", "goods not found");
            return result;
        }

        if (goods.getStock() <= 0) {
            result.put("code", 5020);
            result.put("msg", "empty");
            return result;
        }

        // 2. 检查购物车是否为空
        if (order == null) {
            // 创建新的虚拟订单对象
            order = new Order();
            order.setTotal(0.0);
            order.setAmount(0);
            order.setUserId(user.getId()); // 设置订单关联的用户ID
            order.setUser(user);
            List<Item> items = new ArrayList<>();
            order.setItemList(items);
        }

        // 4. 判断购物车中是否已存在该商品，存在则更新数量，不存在则新增
        boolean isExist = false; // 是否存在标志，初始值为 false
        List<Item> itemList = order.getItemList(); // 获取购物车中的商品列表


        // 循环购物车中的商品
        for (int i = 0; i < itemList.size(); i++) {
            // 获取当前正在被循环的商品对象信息
            Item item = itemList.get(i);

            // 1. 判断购物车中是否已经存在将要添加的商品
            if (item.getGoodId() == goodsId) {
                item.setAmount(item.getAmount() + 1);
                isExist = true;
                break;
            }
        }
        // 要添加的商品在购物车中不存在
        if (!isExist) {
            // 创建一个新的商品对象
            Item item = new Item();
            item.setAmount(1); // 商品数量设置为 1
            item.setGoods(goods); // 商品的详细信息
            item.setPrice(goods.getPrice()); // 商品的价格
            item.setGoodId(goodsId); // 商品id
            // 将新的商品添加到购物车中
            itemList.add(item);
        }

        // 更新订单总金额和购买商品数量
        double total = order.getTotal() + goods.getPrice(); // 订单总金额加上新商品价格
        int amount = order.getAmount() + 1; // 购物总数量加一


        order.setTotal(total);
        order.setAmount(amount);
        order.setItemList(itemList); // 将更新后的商品列表放回购物车


        result.put("code", 200);
        result.put("order", order);

        return result;
    }

    @Override
    public Map<String, Object> updateCartInfo(int goodsId, Order order) {
        Map<String, Object> result = new HashMap<>();

        // 获取购物车中的所有商品信息
        List<Item> itemList = order.getItemList();

        for (int i = 0; i < itemList.size(); i++) {
            // 获取正在被循环的商品
            Item item = itemList.get(i);

            // 查找要更新的商品
            if (item.getGoodId() == goodsId) {
                item.setAmount(item.getAmount() - 1);

                // 判断当前购物车中的商品数量是否小于等于0
                if (item.getAmount() <= 0) {
                    // 移除商品
                    itemList.remove(i);
                }

                // 更新虚拟订单的总金额
                order.setTotal(order.getTotal() - item.getPrice());

                // 更新虚拟订单的总数量
                order.setAmount(order.getAmount() - 1);

                break;
            }
        }
        if (itemList.size() <= 0) {
            // 重置虚拟订单
            order = null;
        }

        result.put("code", 200);
        result.put("order", order); // 返回处理结果
        return result;

    }

    @Override
    public Map<String, Object> deleteCartInfo(int goodsId, Order order) {
        Map<String, Object> result = new HashMap<>();

        // 获取购物车中的所有商品信息
        List<Item> itemList = order.getItemList();

        for (int i = 0; i < itemList.size(); i++) {
            // 获取正在被循环的商品
            Item item = itemList.get(i);

            int xorder =item.getAmount();

            // 查找要更新的商品
            if (item.getGoodId() == goodsId) {
                item.setAmount(0);

                // 判断当前购物车中的商品数量是否小于等于0
                if (item.getAmount() <= 0) {
                    // 移除商品
                    itemList.remove(i);
                }

                // 更新虚拟订单的总金额
                order.setTotal(order.getTotal() - item.getPrice()*xorder);

                // 更新虚拟订单的总数量
                order.setAmount(order.getAmount() - xorder);

                break;
            }
        }
        if (itemList.size() <= 0) {
            // 重置虚拟订单
            order = null;
        }

        result.put("code", 200);
        result.put("order", order); // 返回处理结果
        return result;
    }

    @Override
    public Map<String, Object> createRealOrder(Order order) {

        Map<String, Object> result = new HashMap<>();

        if (order == null) {
            result.put("code",5024);
            result.put("msg","购物车没有数据!");
            return result;
        }

        List<Item> itemList = order.getItemList();

        for (Item item : itemList) {

            int byNum= item.getAmount();
            int goodsId = item.getGoodId();
            Goods goodsInfo = goodsMapper.getGoodsInfoById(goodsId);
            int num = goodsInfo.getStock();

            if (num < byNum) {

                result.put("code",5025);
                result.put("msg", "商品"+goodsInfo.getName()+"不足，剩余"+num+"件!");
                return result;

            }
        }

        order.setStatus(1);
        SimpleDateFormat format = new SimpleDateFormat("yyy-MM-dd HH:mm:ss");
        String now = format.format(new Date());
        order.setSystime(now);

        orderMapper.insertDataToOrder(order);
        System.out.println(order);

        try {
            if (order.getId() <= 0) {
                result.put("code", 5026);
                result.put("msg", "订单创建失败，订单信息添加到表时发生错误!");
                return result;
            }

            // 把购物车中商品(1或n个)，添加到item表中(订单商品表)
            for (Item item : order.getItemList()) {
                // 更新商品信息(订单信息和商品信息产生关联)
                item.setOrderId(order.getId());
                // 把当前正在循环的商品添加到订单商品表中
                itemMapper.insertDataToItem(item);
            }

            result.put("code", 200);
            // 其他成功时的处理...
        } catch (Exception e) {
            result.put("code", 5026);
            result.put("msg", "订单创建失败，订单信息添加到表时发生错误!");
            return result;
        }

        result.put("code", 200);
        return result;
    }

    @Override
    public Map<String, Object> updateOrder(Order order) {

        Map<String, Object> result = new HashMap<>();



        if (order.getId() <= 0) {
            result.put("code", 5027);
            result.put("msg", "更新失败，订单不存在!");
            return result;
        }

        order.setStatus(2);
        int res = orderMapper.updateOrder(order);

        if (res > 0) {
            result.put("code",200);

        }else {
            result.put("code",5027);
            result.put("msg", "失败，表更新错误！");

        }
        return result;
    }

    @Override
    public List<Order> selectOrderByUserId(int userId) {
        
        List<Order> orders = orderMapper.getOrderByUserId(userId);

        for (Order order : orders) {
            // 获取订单id
            int orderId = order.getId();

            // 获取订单商品---> item表
            List<Item> items = itemMapper.getItemByOrderId(orderId);
//            System.out.println(order);

            for (Item item : items) {
                // 获取商品id
                int goodsId = item.getGoodId();  // 修正获取商品id的语法错误

                // 根据商品id获取商品信息
                Goods goods = goodsMapper.getGoodsInfoById(goodsId);

                // 把商品详情添加到商品简要信息中
                item.setGoods(goods);

            }

            order.setItemList(items);

        }



        return orders;

    }

    @Override
    public List<Order> handleOrderByStatus(int status, int page, int size) {
        List<Order> orders = new ArrayList<>();
        if (status == 0){
            orders = orderMapper.getAllOrder((page-1)*size,size);
        }else if (status == 1){
            orders = orderMapper.getOrderListPageByStatus(1,(page-1)*size,size);
        } else if (status == 2) {
            orders = orderMapper.getOrderListPageByStatus(2,(page-1)*size,size);
        } else if (status == 3) {
            orders = orderMapper.getOrderListPageByStatus(3,(page-1)*size,size);
        } else if (status == 4) {
            orders = orderMapper.getOrderListPageByStatus(4,(page-1)*size,size);
        }
        for (Order order : orders) {
            order.setUser(userMapper.findUserById(order.getUserId()));
            List<Item> itemList = itemMapper.getItemByOrderId(order.getId());
            for (Item item : itemList) {
                Goods goodsById = goodsMapper.getGoodsInfoById(item.getGoodId());
                item.setGoods(goodsById);
            }
            order.setItemList(itemList);
        }
        return orders;
    }


    @Override
    public int handleOrderOperate(String operate, int id) {
        int i = 0;
        if ("finish".equals(operate)) {
            i = orderMapper.updateOrderById(4, id);
        } else if ("send".equals(operate)) {
            i = orderMapper.updateOrderById(3, id);
        } else if ("delete".equals(operate)) {
            i = orderMapper.updateOrderById(0, id);
        }
        return i;
    }


}
