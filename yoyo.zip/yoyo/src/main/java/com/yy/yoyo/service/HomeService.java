package com.yy.yoyo.service;

import com.yy.yoyo.pojo.Goods;
import com.yy.yoyo.pojo.Type;

import java.util.List;

public interface HomeService {
    List<Type> getAllTypes();
    List<Goods> getGoodsListByType(int type);
    List<Goods> getGoodsPageByTopType(int typeId, int page, int size);
    int getGoodsTotalByTopType(int typeId);

}
