package com.yy.yoyo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YoyoApplicationTests {

    @Test
    void contextLoads() {
    }

}
